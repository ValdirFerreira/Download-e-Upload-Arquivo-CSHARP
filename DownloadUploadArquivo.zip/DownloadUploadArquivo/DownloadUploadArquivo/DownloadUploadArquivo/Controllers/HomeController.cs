﻿using DownloadUploadArquivo.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DownloadUploadArquivo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }


        public ActionResult ListaArquivo()
        {
            return View(RetornaListaArquivos());
        }

        public ActionResult Upload(HttpPostedFileBase arquivo)
        {

            if (arquivo != null && arquivo.ContentLength > 0)
            {
                var NomeArquivo = Path.GetFileName(arquivo.FileName);
                var caminhoCompletoSalvar = Path.Combine(Server.MapPath("~/Arquivos"), NomeArquivo);

                arquivo.SaveAs(caminhoCompletoSalvar);
            }

            return View("Index");
        }


        public FileResult Download(string id)
        {
            var IdArquivo = Convert.ToInt32(id);

            var ArquivosLista = RetornaListaArquivos();

            string NomeArquivo = (from ListaArquivo in ArquivosLista
                                  where ListaArquivo.Id == IdArquivo
                                  select ListaArquivo.Caminho).First();


            string contentType = "";
            string extensao = Path.GetExtension(NomeArquivo);
            string nomeArquivoV = Path.GetFileNameWithoutExtension(NomeArquivo);
            if (extensao.Equals(".pdf"))
                contentType = "application/pdf";
            if (extensao.ToUpper().Equals(".JPG") || extensao.ToUpper().Equals(".GIF") || extensao.ToUpper().Equals(".PNG")) contentType = "application/image";

            return File(NomeArquivo, contentType, nomeArquivoV + extensao);
        }

        public List<Arquivo> RetornaListaArquivos()
        {
            List<Arquivo> Lista = new List<Arquivo>();

            DirectoryInfo Dir = new DirectoryInfo(Server.MapPath("~/Arquivos"));

            int IdArquivo = 1;

            foreach (var item in Dir.GetFiles())
            {
                //Lista.Add(new Arquivo { Id = IdArquivo, Nome = item.Name, Caminho = item.FullName + @"\" + item.Name });
                Lista.Add(new Arquivo { Id = IdArquivo, Nome = item.Name, Caminho = item.FullName });
                IdArquivo++;
            }

            return Lista;
        }

        public Arquivo RetornaArquivos()
        {
            DirectoryInfo Dir = new DirectoryInfo(Server.MapPath("~/Arquivos/expensmat_3_2.pdf"));

            //Arquivo _Arquivo = new Arquivo { Nome = Dir.Name, Caminho = Dir.FullName + @"\" + Dir.Name };
            Arquivo _Arquivo = new Arquivo { Nome = Dir.Name, Caminho = Dir.FullName };
            _Arquivo.Id = 1;

            return _Arquivo;
        }

    }
}